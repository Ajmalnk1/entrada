<aside class="recent-block recent-list recent-wide-thumbnail">
	<div class="container">
		<?php echo entrada_recently_viewed_product(); ?>
   </div>     
</aside>