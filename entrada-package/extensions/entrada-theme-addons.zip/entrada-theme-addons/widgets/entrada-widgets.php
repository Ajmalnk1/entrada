<?php

if ( file_exists( get_template_directory() . '/admin/widgets/footer-contact-widget.php' ) ) {
	require_once( get_template_directory() . '/admin/widgets/footer-contact-widget.php' );
}
	
if ( file_exists( get_template_directory() . '/admin/widgets/entrada-categories-widget.php' ) ) {
	require_once( get_template_directory() . '/admin/widgets/entrada-categories-widget.php' );
}
	
if ( file_exists( get_template_directory() . '/admin/widgets/entrada-popular-posts-widget.php' ) ) {
	require_once( get_template_directory() . '/admin/widgets/entrada-popular-posts-widget.php' );
}
	
if ( file_exists( get_template_directory() . '/admin/widgets/entrada-taxonomy-widget.php' ) ) {
	require_once( get_template_directory() . '/admin/widgets/entrada-taxonomy-widget.php' );
}
	
if ( file_exists( get_template_directory() . '/admin/widgets/entrada-gallery-posts-widget.php' ) ) {
	require_once( get_template_directory() . '/admin/widgets/entrada-gallery-posts-widget.php' );
}
	
if ( file_exists( get_template_directory() . '/admin/widgets/entrada-subscribe-widget.php' ) ) {
	require_once( get_template_directory() . '/admin/widgets/entrada-subscribe-widget.php' );
}
	
if ( file_exists( get_template_directory() . '/admin/widgets/entrada-poll-widget.php' ) ) {
	require_once( get_template_directory() . '/admin/widgets/entrada-poll-widget.php' );
}
	
/* FILTER WIDGETS...............*/
if ( file_exists( get_template_directory() . '/admin/widgets/entrada-filter-region-widget.php' ) ) {
	require_once( get_template_directory() . '/admin/widgets/entrada-filter-region-widget.php' );
}	
	
if ( file_exists( get_template_directory() . '/admin/widgets/entrada-filter-activity-type-widget.php' ) ) {
	require_once( get_template_directory() . '/admin/widgets/entrada-filter-activity-type-widget.php' );
}
	
if ( file_exists( get_template_directory() . '/admin/widgets/entrada-filter-tour-tag-widget.php' ) ) {
	require_once( get_template_directory() . '/admin/widgets/entrada-filter-tour-tag-widget.php' );
}	
	
if ( file_exists( get_template_directory() . '/admin/widgets/entrada-filter-activity-level-widget.php' ) ) {
	require_once( get_template_directory() . '/admin/widgets/entrada-filter-activity-level-widget.php' );
}	
	
if ( file_exists( get_template_directory() . '/admin/widgets/entrada-filter-price-range-widget.php' ) ) {
	require_once( get_template_directory() . '/admin/widgets/entrada-filter-price-range-widget.php' );
} ?>